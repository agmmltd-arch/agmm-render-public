#!/usr/bin/env python3
"""static_check.py: sealed-package guard for the R03 composition (runs on the Actions runner before render).
Fails on: any file type other than html/js/woff2/txt/py, any external URL other than none, any email/phone/key-like string, any file over 1 MiB."""
import os, re, sys
bad = []
ok_ext = {'.html', '.js', '.woff2', '.txt', '.py'}
for root, _, fs in os.walk('.'):
    for f in fs:
        p = os.path.join(root, f)
        if os.path.splitext(f)[1] not in ok_ext:
            bad.append('type ' + p)
        if os.path.getsize(p) > 1048576:
            bad.append('size ' + p)
        if f.endswith(('.html',)):
            t = open(p, encoding='utf-8').read()
            for pat, nm in ((r'https?://', 'url'), (r'[\w.+-]+@[\w-]+\.[\w.]+', 'email'), (r'\bsk-[A-Za-z0-9]{6,}', 'key'), (r'(?<!\d)(?:\+?44|0)\s?\d[\d\s-]{8,}\d', 'phone')):
                if re.search(pat, t):
                    bad.append(nm + ' in ' + p)
if bad:
    print('STATIC CHECK FAIL', bad); sys.exit(1)
print('STATIC CHECK PASS')
